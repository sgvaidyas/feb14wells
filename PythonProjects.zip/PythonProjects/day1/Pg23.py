s="sample"
del (s)
try:
    print(s)
except NameError:
    print("the variable does not exist")
except:
    print("Genric exception")
finally:
    print("i execute no matter what happens")

