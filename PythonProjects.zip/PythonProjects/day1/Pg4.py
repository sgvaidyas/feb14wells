name = input("Enter the name = ")
print("Welcome ",name)
m1 = int(input("Enter marks 1 = "))
m2 = int(input("Enter marks 2 = "))
total = m1+m2
avg = total/2
print("TOTAL = ",total," \nAVERAGE = ",avg)
