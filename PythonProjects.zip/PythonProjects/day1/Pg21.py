sum = lambda a,b:a+b
diff = lambda a,b:a-b
square = lambda a:a*a
cube = lambda a:a*a*a
print(sum(22,33))
print(diff(11,2))
print(square(7))
print(cube(3))
msg = lambda :"hi this is a function without params"
print(msg())