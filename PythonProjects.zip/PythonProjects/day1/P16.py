def myfun(**kwargs):
    print(kwargs)

myfun(name='shilpa',email='aaa@m.com')
myfun(roll=11,sub='python')