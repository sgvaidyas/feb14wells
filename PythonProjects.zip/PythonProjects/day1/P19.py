#Pass by value
def myfun():
    global x
    x=x+100
    print("in fun ",x)

x = 20
print("x before func call = ",x)
myfun()
print("x after func call = ",x)