#function with default parameters
def myfunction(a,b,c=10,d=20):
   print(a,b,c,d )
   return a+b+c+d

res = myfunction(22,33)
print(res)

res = myfunction(22,33,20)
print(res)

res = myfunction(22,33,20,5)
print(res)

