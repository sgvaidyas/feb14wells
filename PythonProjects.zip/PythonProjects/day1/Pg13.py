#function with default parameters
def myfunction(a,b,c,d):
   print("a={0} b={1} c={2} d={3}".format(a,b,c,d))
   return a+b+c+d

print(myfunction(b=11,c=33,a=44,d=99))

