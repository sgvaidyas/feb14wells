'''
a = 33
b = a
print(a,b)
print(id(a),id(b))
b = 888
print(id(a),id(b))
'''
import copy

'''
l = [11,22,33,44,55]
b = l
print(l,b)
print(id(l),id(b))
b[3] = 9999
print(l,b)
print(id(l),id(b))

'''
'''
l = [11,22,33,44,55]
b = copy.copy(l)
print(l,b)
print(id(l),id(b))
b[3] = 9999
print(l,b)
print(id(l),id(b))
'''
'''
l = [11,22,33,44,[10,20,30]]
print(len(l))
print(l[4][2])
'''
l = [11,22,[10,20,30]]
b = copy.deepcopy(l)
b[2][1] = 999
print(l)
print(b)