try:
    a = int(input("Enter a num = "))
    b = int(input("Enter a den = "))
    res = a/b
    print(res)
except ZeroDivisionError:
    print("ERROR:Denominator should not b 0")
except ValueError:
    print("ERROR: Put int as the input")
except:
    print("generic error")
print("------------")
print("------------")
print("------------")