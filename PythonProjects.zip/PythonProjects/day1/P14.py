'''l = []
print(l)
a = [11,22,33,44]
print(a)
a.append(999)
print(a)
a.extend([99,88,77])
print(a)
a.append([99,88,77])
print(a)'''
'''
#    0   1  2  3  4
a = [11,22,33,44,55]
#   -5 -4 -3 -2 -1
print(a[0],a[-5])
print("----------------------")
for i in range(len(a)):
    print("{0} : {1} ".format(i,a[i]))
'''
'''
a = [11,22,33,44,55,66,77]
for x in a:
    print(x)
'''

'''
a = [11,22,33,44,55,66,77]
for i in range(-len(a), 0):
    print(i,a[i])
'''
'''
a = [11,22,33,44,55]
for i in range(len(a)):
    print(a[i])
    a[i]=a[i]+10
print(a)
print("---------------")
a = [11,22,33,44,55]
for x in a:
    print(x)
    x=x+10
print(a)
'''
'''
t = (11,22,33,44,55,66)
print(len(t))
for i in range(len(t)):
    print(t[i])
print("------")
for i in range(-len(t), 0):
    print(t[i])

'''
'''
val1 = (22)
print(val1, type(val1))
t = (22,)
print(t, type(t))
'''
'''
d ={}
d['name']='shilpa'
d['marks'] = 66
d['fees']=20000
d['name']='shreya'
print(d)
print(d['fees'])
'''
s = set()
print(s,type(s))
s.add(11)
s.add(22)
s.add(11)
s.add(99)
print(s)
