import sys
'''
import sys
sys.stdout.write('Major twist')

'''
'''
def myfun(*a):
    print(*a,file=sys.stderr)
myfun(11,22,33)
'''
'''
for line in sys.stdin:
    if 'q' == line.rstrip():
        break
    print(f'data = {line}')
    
'''