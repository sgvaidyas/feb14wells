l=["red","violet","blue"]
try:
    ch = int(input("Choose a number: "))
    print(l[ch])
except IndexError:
    print("let the index be in range from 0-",len(l))
except:
    print("Generic")