'''
if and else
ask user to enterthe marks >35 = pass else fail
'''
per = int(input("Enter the per = "))
if per>=35:
    print("Pass : congratulations")
    print("------------------------")
else:
    print("------------------------")
    print("Fail : Better luck next time")
    print("------------------------")

print("END OF PROGRAM")
