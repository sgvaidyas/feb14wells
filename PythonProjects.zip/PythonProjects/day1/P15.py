#multiple arguments
def getVal(*myitems):
    print(myitems)
    for i in myitems:
        print(i)

getVal(11,22,33,44,55)
getVal(11,22,33)
