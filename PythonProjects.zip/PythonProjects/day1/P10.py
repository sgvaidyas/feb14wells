#functions without parameters and no return type
#definition of function
def add():
    a = int(input("Enter val of a = "))
    b = int(input("Enter the val of b = "))
    res = a+b
    print("SUM  = ",res)
def sub():
    a = int(input("Enter val of a = "))
    b = int(input("Enter the val of b = "))
    res = a-b
    print("DIFF  = ",res)
def mul():
    a = int(input("Enter val of a = "))
    b = int(input("Enter the val of b = "))
    res = a*b
    print("PROD  = ",res)
def div():
    a = int(input("Enter val of a = "))
    b = int(input("Enter the val of b = "))
    res = a/b
    print("QUOT  = ",res)



#main repeat and ask user to give inputs
flag = True
while flag==True:
    print("1 Add\t2 Sub\t3 Mul\t4 Div\t5 EXIT")
    ch = int(input("Enter the choice = "))
    if ch==1:
        add()   #function call
    elif ch ==2:
        sub()
    elif ch == 3:
        mul()
    elif ch == 4:
        div()
    elif ch == 5:
        print("Coming out of loop")
        flag=False
    else:
        print("invalid choice")

print("------PROGRAM ENDS--------")