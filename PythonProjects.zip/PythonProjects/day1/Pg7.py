'''
multiple conditions
cond1 cond2  AND  OR
------------------------
T      T      T    T
T      F      F    T
F      T      F    T
F      F      F    F
'''
per = float(input("Enter the percentage = "))
if per<0 or  per>100:
    print("invalid percentage")
elif per>=0 and per<35:
    print("FAIL")
else:
    print("PASS")