class MyClass(Exception):
    pass

try:
    per = int(input("Enter per = "))
    if per<0 or per>100:
        raise MyClass
    print("valid per")
except MyClass:
    print("Exception occured: invalid marks")
except:
    print("generic")