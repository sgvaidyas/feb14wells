a = 11
b = 55.7
c = "hi this is a string"
d = '99987'
e = True
print("a=",a)
print(type(a))
print("b=",b)
print(type(b))
print("c=",c)
print(type(c))
print("d=",d)
print(type(d))
print("e=",e)
print(type(e))