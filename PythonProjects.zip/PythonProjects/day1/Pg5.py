'''
this is a program
to demonstrate the calculator
Author: Shilpa
'''
a = float(input("Enter the number 1 = "))
b = float(input("Enter the number 2 = "))
#this is a program for arithmatic operations
sum = a+b
diff = a-b
prod = a*b
quot = a/b
exp = a**b #2**3 = 2*2*2
quotInt = a//b #5/2 = 2.5  5//2 = 2
print("SUM = ",sum, " DIFF = ",diff," PROD = ",prod," QUOT = ",quot)
print("EXP = ",exp," QUOT (INT) ",quotInt)
