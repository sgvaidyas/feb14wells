#Pass by reference
def myfun(x):
    x.extend([2222,6666])
    print("in fun ",x)

x = [11,22]
print("x before func call = ",x)
myfun(x)
print("x after func call = ",x)