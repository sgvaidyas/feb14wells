var1 = '8789789789'
print(var1, type(var1))

a = '99'
b = '77'
print(a+b)

a = 99
b = 77
print(a+b)

mystring = "hey it's me"
print(mystring)

m1 = "he said \"not to interfere\" .... now what can be done"
print(m1)
m2 = " this is 'a sample ' just a demo"
print(m2)





