for i in range(10):
    print(i)
print("----------------")
for i in range(2,7):
    print(i)
print("----------------")
# i = 2  i<10  i=i+2
for i in range(2,10,2):
    print(i)

print("----------------")
low = int(input("Enter low val = "))
high = int(input("Enter high val = "))
for i in range(low,high):
    print(i)
