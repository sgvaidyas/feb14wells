fp = open('mytextfile' , 'r')

content = fp.readlines()
print(content)

fp.close()