def readdata(filename):
    try:
        fp = open(filename,'r')
        lines = fp.readlines()
        print("lines = ",lines)
        for i in range(len(lines)):
            print(i+1,lines[i] )
        fp.close()
    except FileNotFoundError:
        print("No such file exists")
    except:
        print("GENERIC")

readdata("names")