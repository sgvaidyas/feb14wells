from FileHandling import *
filename = "Products"

while True:
    print("1 Add Product 2 Display Product 3 Show All Products 4 Exit ")
    ch = int(input("Enter the choice = "))
    if ch ==1:
        addProduct(filename)
    elif ch==2:
        dispProduct(filename)
    elif ch==3:
        dispAllProduct(filename)
    elif ch==4:
        break
    else:
        print("Invalid choice")