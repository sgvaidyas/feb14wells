'''
implementing the package:MyPackage
'''
from MyPackage import *
print("Current execution ", __name__)
print(sum(22,3))
print(prod(11,2))
print(rem(11,2))

myfun()
print(sum_three(11,22,33))