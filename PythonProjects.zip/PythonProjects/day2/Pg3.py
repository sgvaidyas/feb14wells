import sys
print(sys.modules)
print(sys.path)