import mysql.connector

mydb = mysql.connector.connect(
    host='localhost',
    user='root',
    password='root',
    database='mydb'
)
mycursor = mydb.cursor()
sql = "insert into product values (%s,%s,%s)"
values = ("14","MARGO","88")
mycursor.execute(sql,values)
mydb.commit()
print('record added')


