def addProduct(filename):
    pid  = input("Enter the PID = ")
    pname= input("Enter the PNAME = ")
    price= input("Enter the PRICE = ")
    s = [pid,pname,price]
    s = (',').join(s)
    try:
        fp = open(filename,'a')
        fp.write(s+'\n')
        fp.close()
    except FileNotFoundError:
        print("ERROR:FILE NOT FOUND")
    except:
        print("GENERIC ERROR")