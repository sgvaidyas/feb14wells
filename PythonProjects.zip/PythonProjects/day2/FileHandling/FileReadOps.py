def searchProduct(filename):
    sk = input("Enter the PID = ")
    try:
        fp = open(filename,'r')
        products = fp.readlines()
        for i in range(len(products)):
            rec = products[i]
            x = rec.split(',')
            if sk == x[0]:
                return True,i
        else:
            return False,-1
        fp.close()
    except FileNotFoundError:
        print("ERROR: FILE DOESNOT EXIST")
    except:
        print("GENERIC ERROR")





def dispProduct(filename):
    isFound, ind = searchProduct(filename)
    try:
        fp = open(filename,'r')
        products = fp.readlines()
        if isFound==True:
            print("RECORD".center(60,"*"))
            print(products[ind])
        else:
            print("PRODUCT DOES NOT EXIST")
        fp.close()
    except:
        print("GENERIC")


def dispAllProduct(filename):
    try:
        fp = open(filename,'r')
        products = fp.readlines()
        for i in range(len(products)):
            print(i+1,"=",products[i])
        fp.close()
    except FileNotFoundError:
        print("ERROR: FILE DOESNOT EXIST")
    except:
        print("GENERIC ERROR")