fp = open('mytextfile' , 'r')

content = fp.read()
print("the file contents are ")
print(content)

fp.close()