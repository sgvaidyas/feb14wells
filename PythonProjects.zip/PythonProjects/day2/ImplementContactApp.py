from CRUD_LIST import *
master = []
while True:
    print("1 Create 2 Display 3 Search 4 Update 5 Delete 6 Exit")
    ch  = int(input("Enter the choice = "))
    if ch == 1:
        rec = createContact(master)
        master.append(rec)
    elif ch==2:
        print("ALL CONTENT".center(60,'*'))
        for rec in master:
            displayContent(rec)
    elif ch == 3:
        searchkey  = input("Enter the email u want to search = ")
        ispresent = search(master,searchkey)
        if ispresent==True:
            print("The record exists")
        else:
            print("the record doesnt exist")
    elif ch == 4:
        searchkey = input("Enter the email u want to search = ")
        ispresent = search(master, searchkey)
        if ispresent == True:
            print("The record exists , you can now update")
            update(master,searchkey)
        else:
            print("the record doesnt exist")
    elif ch == 5:
        searchkey = input("Enter the email u want to search = ")
        ispresent = search(master, searchkey)
        if ispresent == True:
            print("The record exists , you can now update")
            delete(master,searchkey)
        else:
            print("the record doesnt exist")

    elif ch == 6:
        break
    else:
        print("Invalid choice")