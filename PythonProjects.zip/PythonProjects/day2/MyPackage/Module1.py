sum = lambda a,b:a+b
diff = lambda a,b:a-b
prod = lambda a,b:a*b
quot = lambda a,b:a/b
exp = lambda a,b:a**b
rem = lambda a,b:a%b