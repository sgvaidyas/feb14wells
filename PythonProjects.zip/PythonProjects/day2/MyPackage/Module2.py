def myfun():
    print("I m just here")
    print("to say HI")
    print("NAME : ",__name__)

sum_three = lambda a,b,c:a+b+c