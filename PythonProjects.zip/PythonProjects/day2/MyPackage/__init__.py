from MyPackage.Module1 import *
from MyPackage.Module2 import *
