fp = open("mydata","w")

fp.write("hi this is sample\n")
fp.write("just dumping data")

fp.close()