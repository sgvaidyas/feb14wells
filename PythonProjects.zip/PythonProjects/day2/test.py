'''
s = "shilpa"
print(s.center(60,"-"))
'''

'''while True:
    s = input("Enter = ")
    print(s)
    if s.isalpha() == True:
        print("the valid name ")
        break
    else:
        print("name should contain only chars")
'''
'''

for i in range(20):
    print(i)
    if(i==60):
        break
else:
    print("i m in else")

print("--------")'''

fp = open("Products",'r')

products = fp.readlines()
for i in range(len(products)):
    rec = products[i]
    x = rec.split(',')
    print(x[0])

fp.close()


