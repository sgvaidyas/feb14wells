import sys
sys.stdout.write('Hey this is a sample ')
l = [11,22,33]
print(l)
print(l,file=sys.stderr)