'''
This is a generic module file that can be used
in any other calling file with 2 modules
'''
def readData():
    l=[]
    name = input("Enter the name = ")
    roll = int(input("Enter the roll num = "))
    fees = float(input("Enter the fees = "))
    l.extend([name,roll,fees])
    return l

def printData(l):
    print("------------------")
    print("NAME = ",l[0])
    print("ROLL = ", l[1])
    print("FEES = ", l[2])
    print("------------------")

def myfun1():
    pass

def myfun2():
    pass
