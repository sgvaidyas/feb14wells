import sys
print(sys.version)
print("-------------")
print("Enter some data below :")
for eachLine in sys.stdin:
    if eachLine.strip().lower() == 'quit':
        break
    print("Line" ,eachLine)
print("End of the loop")