fp = open('mytextfile' , 'r')

content = fp.readline()
print(content)
content = fp.readline()
print(content)
fp.close()