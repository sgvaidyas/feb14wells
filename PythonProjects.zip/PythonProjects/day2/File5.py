fp = open("names","a")

fp.write("Lakshmi\n")
fp.write("Soumya\n")
fp.write("Naveen\n")
fp.write("Sri\n")

fp.close()