'''
this is implementation of Mymodule 1 file
'''
'''
import  Mymodule1

rec = Mymodule1.readData()
Mymodule1.printData(rec)
'''
'''
import  Mymodule1 as Mymod

rec = Mymod.readData()
Mymod.printData(rec)
'''

#from Mymodule1 import *
from Mymodule1 import readData,printData

rec = readData()
printData(rec)
