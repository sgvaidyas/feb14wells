'''
Reading a list
writing/displaying the list
'''
def createContact(master):
    name = input("Enter the name = ")
    phone = int(input("Enter the phone = "))
    while True:
        email = input("Enter the email = ")
        valid = True
        for x in master:
            if x[2] == email:
                print("This email already exists")
                valid = False
                break
        if valid==True:
            break

    return [name,phone,email]

def displayContent(rec):
    print("***".center(60,"-"))
    print("NAME".ljust(20),":",rec[0])
    print("PHONE".ljust(20), ":", rec[1])
    print("EMAIL".ljust(20), ":", rec[2])


def search(master,searchkey):
    for x in master:
        if searchkey == x[2]:
            displayContent(x)
            return True
    else:
        return False

def update(master,searchkey):
    for i in range(len(master)):
        x = master[i]
        if searchkey == x[2]:
            ch = int(input("1 Update name 2 update phone 3 update both"))
            if ch == 1:
                upName = input("Enter the name u want to update = ")
                master[i][0] = upName
            elif ch == 2:
                upPhone = int(input("Enter the phone u want to update = "))
                master[i][1] = upPhone
            elif ch == 3:
                upName = input("Enter the name u want to update = ")
                master[i][0] = upName
                upPhone = int(input("Enter the phone u want to update = "))
                master[i][1] = upPhone
            else:
                print("Invalid choice")

def delete(master,searchkey):
    for i in range(len(master)):
        x = master[i]
        if searchkey == x[2]:
            ch = int(input("Are you sure that this record should be deleted? Press 1 to del ="))
            if ch==1:
                del master[i]
            return
