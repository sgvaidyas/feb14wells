myvar = r'C:\Users\Administrator\Desktop\readme.txt'
fp = open(myvar,'r')

cont = fp.read()
print(cont)

fp.close()