import mysql.connector

mydb = mysql.connector.connect(
    host='localhost',
    user='root',
    password='root',
    database='mydb'
)
mycursor = mydb.cursor()
sql = "select * from product"
mycursor.execute(sql)
mydata = mycursor.fetchall()
print("---------------")
for rec in mydata:
    print(rec)
